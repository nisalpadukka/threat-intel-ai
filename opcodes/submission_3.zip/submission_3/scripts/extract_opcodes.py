import os
import csv
import logging
from ghidra.app.util.headless import HeadlessScript
from ghidra.program.model.address import AddressSet

# Get script arguments and determine the save folder
argv = getScriptArgs()

try:
    if len(argv) == 1:
        results_folder = argv[0]
    else:
        print("No results folder provided, using current directory.")
        results_folder = os.getcwd()  # Default to current working directory
except Exception as e:
    print("An error occurred while setting parameters: {}".format(e))

# Ensure results folder exists
if not os.path.exists(results_folder):
    os.makedirs(results_folder)

program_name = currentProgram.getName()
base_name = os.path.splitext(program_name)[0]  # Remove only the last extension
csv_file_path = os.path.join(results_folder, base_name + '.opcode')
print("Opcode file will be saved at: {}".format(csv_file_path))

try:
    with open(csv_file_path, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(['addr', 'opcode'])

        memory_blocks = currentProgram.getMemory().getBlocks()

        if memory_blocks:
            for block in memory_blocks:
                block_name = block.getName()
                address_set = AddressSet(block.getStart(), block.getEnd())
                instructions = currentProgram.getListing().getInstructions(address_set, True)
                for instr in instructions:
                    addr = instr.getAddress().toString()
                    opcode = str(instr).split(' ')[0]
                    csvwriter.writerow([addr, opcode])
        else:
            instructions = currentProgram.getListing().getInstructions(True)
            for instr in instructions:
                addr = instr.getAddress().toString()
                opcode = str(instr).split(' ')[0]
                csvwriter.writerow([addr, opcode])

except Exception as e:
    print("An error occurred while writing the files: {}".format(e))
